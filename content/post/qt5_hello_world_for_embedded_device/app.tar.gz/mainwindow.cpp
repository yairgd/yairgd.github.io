#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>

MainWindow::MainWindow(QWidget *parent) :
	QMainWindow(parent),
	ui(new Ui::MainWindow)
{
	ui->setupUi(this);
	connect(ui->install, SIGNAL(clicked()), this, SLOT(install())  );
	connect(ui->reboot, SIGNAL(clicked()), this, SLOT(reboot())  );

	process = new QProcess();
//      it is also possible to conne signal like that, or connect it a lambda like in the install function
//	connect(process, SIGNAL(readyReadStandardOutput()), this, SLOT(readyReadStandardOutput()));

}

void MainWindow::install()
{

	QString program = "/bin/bash -c './install.sh'";
	QString sh = qgetenv("SHELL");
	process->setProgram(sh);

	connect(process, &QProcess::readyReadStandardOutput, [this] {
				readyReadStandardOutput();
			});

	process->start(program );


}


void MainWindow::reboot()
{

	QString program = "/bin/bash -c './reboot.sh'";
	QString sh = qgetenv("SHELL");
	process->setProgram(sh);

	connect(process, &QProcess::readyReadStandardOutput, [this] {
				readyReadStandardOutput();
			});

	process->start(program );


}




// slot connected to QProcess::finished
void MainWindow::readyReadStandardOutput()
{

	while(process->canReadLine()){
		ui->plainTextEdit->appendPlainText(process->readAllStandardError());
		ui->plainTextEdit->appendPlainText(process->readAllStandardOutput());

	}
}

MainWindow::~MainWindow()
{
	delete ui;
}

