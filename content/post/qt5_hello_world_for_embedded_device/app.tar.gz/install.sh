#/bin/bash
ls
echo hello
echo world
exit
